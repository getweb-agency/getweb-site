<?php return array (
  'quote-component' => 'App\\Http\\Livewire\\QuoteComponent',
  'work-component' => 'App\\Http\\Livewire\\WorkComponent',
);