


<?php $__env->startSection('seoTitle', 'Portafolio de proyectos'); ?>
<?php $__env->startSection('seoDescription', 'Portafolio de proyectos de la empresa especializada en hosting, diseño y desarrollo de paginas web profesionales y marketing digital.'); ?>
<?php $__env->startSection('seoKeywords','portafolio, paginas web bogota, hosting, marketing digital'); ?>
<?php $__env->startSection('seoRobots', 'index, follow'); ?>

<?php $__env->startSection('content'); ?>

<div class="flex flex-col space-y-4 space-x-0 sm:space-y-0 sm:flex-row sm:space-x-6 py-5 px-8">
  
  <div class="sm:w-3/4 w-full">

    <a href="/portafolio/proyectos" class="pb-3 border-b flex flex-row items-center">
      <svg class="h-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
      </svg>
      <p>Regresar al portafolio</p>
    </a> 
    <div class="pt-5">
      <?php $__currentLoopData = $wimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <img class="w-full" src="<?php echo e(asset('/images/'.$wi->work_image)); ?>" alt="Getweb">
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  
  <div class="sm:w-1/4 w-full bg-gray-100 p-4">
    <h1 class="text-base font-bold tracking-wide leading-5"><?php echo e($work->title); ?></h1>
    <p class="text-sm leading-tight mt-1 mb-6 text-c-rojo">Proyecto No.<?php echo e($work->id); ?></p>
    <div class="text-gray-600 text-sm">
      <?php echo e($work->body); ?>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\getweb-v2.1\resources\views/portfolio/single.blade.php ENDPATH**/ ?>