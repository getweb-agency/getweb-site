<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH C:\laragon\www\getweb-v2.1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/table.blade.php ENDPATH**/ ?>