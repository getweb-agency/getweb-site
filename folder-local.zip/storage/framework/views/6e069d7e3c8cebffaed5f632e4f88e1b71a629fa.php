<div class="text-center py-8">
  <h2 class="text-base font-bold tracking-wide uppercase <?php echo e($style1); ?>"><?php echo e($text1); ?></h2>
  <p class="mt-2 text-3xl leading-8 font-bold tracking-tight sm:text-4xl uppercase <?php echo e($style2); ?>"><?php echo e($text2); ?></p>
  <span class="mt-4 max-w-2xl text-xl lg:mx-auto <?php echo e($style3); ?>"><?php echo e($text3); ?></span>
</div><?php /**PATH C:\laragon\www\getweb-v2.1\resources\views/components/modulo/section-title.blade.php ENDPATH**/ ?>