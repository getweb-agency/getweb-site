<?php $__env->startComponent('mail::message'); ?>
<img src="https://www.getweb.com.co/svg/main_logo_b.svg" height="50px" style="margin-bottom: 30px;">

# ¡Hola <?php echo e($post->name); ?>, Gracias por realizar tu cotizacion en linea!

Primero que todo queremos agradecer el interés y la confianza que está poniendo en Getweb, estamos seguros que nuestra experiencia de años supliendo las necesidades digitales para múltiples compañías garantizarán un apoyo a las necesidades de tu negocio.

En este correo encontrarás el resumen de tu cotizacion realizada.

<div style="background-color: #f3f3f3; padding: 20px; color: black;">
  <h4> Resumen de la cotización:</h4>
  <small>
    <div style="border-bottom: 1px #d6d6d6 dashed; margin-bottom: 10px; padding-bottom: 10px;">
      Nombre: <?php echo e($post->name); ?><br>
      Teléfono: <?php echo e($post->tel); ?><br>
      Mail: <?php echo e($post->email); ?>

    </div>
    <?php 
    foreach (explode("+",$post->quote) as $values)
    {
      if($values ? $values : '')
        echo $values.'<br>';
    }
    ?>
  </small>
</div>
<br>

<strong>Comunícate con nosotros al 319-589-5064 o has clic en el siguiente botón para escribirnos a WhatsApp,</strong> con gusto le atenderá uno de nuestros representantes que le ayudará con los pasos a seguir del proceso.

¡Espero podamos conversar pronto!

<?php $__env->startComponent('mail::button', ['url' => 'https://api.whatsapp.com/send?phone=573195895064', 'color' => 'success']); ?>
Escríbenos a Whatsapp
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => 'https://getweb.com.co', 'color' => 'primary']); ?>
Visita nuestro sitio web
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Gracias por preferir nuestros servicios. Cordialmente, Equipo <?php echo e(config('app.name')); ?>

<hr>
<small>Getweb diseño y desarrollo Web SAS<br> www.getweb.com.co</small>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\getweb-v2.1\resources\views/emails/notifications/quote.blade.php ENDPATH**/ ?>