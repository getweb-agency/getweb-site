<div class="flex flex-col space-y-4 space-x-0 sm:space-y-0 sm:flex-row sm:space-x-6 py-5 px-8">
  
  <div class="w-full">

    <?php if(empty($works)): ?>
    <div class="bg-gray-100 rounded text-center p-6">
      <div class="leading-tight text-lg font-medium mb-1">
      Estamos actualizando nuestro portalfolio de proyectos, no tenemos proyectos publicados en este momento :(</div> Intenta regresar en algunos dias para ver nuestro nuevo portafolio publicado
    </div>
    <?php endif; ?>

    <dl class="space-y-10 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8 md:gap-y-10">
      <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

       <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.card-work','data' => ['rute' => '/portafolio/proyectos/'.e($work->id).'','image' => 'images/'.e($work->image).'','service' => ''.e($work->title).'']]); ?>
<?php $component->withName('modulo.card-work'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['rute' => '/portafolio/proyectos/'.e($work->id).'','image' => 'images/'.e($work->image).'','service' => ''.e($work->title).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </dl>

    <div class="mt-4">
      <?php echo e($works->links()); ?>

    </div>
  </div>
</div>
<?php /**PATH C:\laragon\www\getweb-v2.1\resources\views/livewire/work-component.blade.php ENDPATH**/ ?>