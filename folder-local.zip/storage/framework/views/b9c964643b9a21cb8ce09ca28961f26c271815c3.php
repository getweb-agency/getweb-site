<div class="sticky top-0 z-40">
  <div class="hidden md:block">
    <nav class="flex justify-between py-4 px-8 bg-white bg-opacity-100">
      <ul class="flex items-center">
        <li>
          <a href="/"> <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.logo.black','data' => ['class' => 'h-12 w-auto']]); ?>
<?php $component->withName('logo.black'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'h-12 w-auto']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> </a>
        </li>
      </ul>
      <ul class="flex items-center space-x-4">
         <?php if (isset($component)) { $__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SingleMenuItem::class, ['rute' => 'hosting/planes-hosting','name' => 'Hosting','icon' => 'M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01']); ?>
<?php $component->withName('single-menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af)): ?>
<?php $component = $__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af; ?>
<?php unset($__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

        <li class="relative -m-2 p-2 flex items-start border-b-2 border-transparent hover:border-pink-400" x-data="{ open: false }">
          <button class="-m-2 p-2 flex items-center focus:outline-none" @click="open = true">
            <svg class="flex-shrink-0 h-6 w-6 text-pink-400 stroke-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
            </svg>
            <div class="ml-1 text-base font-normal hover:font-medium text-gray-900">
              Páginas web
            </div>
          </button>

          <div class="absolute z-20 origin-top-right absolute left-0 mt-10 w-80 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5"
          x-show.transition.duration.200ms.origin.top.right="open"
          @click.away="open = false"
          >
          <div class="py-1" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
            <a href="/paginas-web/wordpress-administrable" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900" role="menuitem">Páginas web administrables</a>
            <a href="/paginas-web/tienda-virtual-ecommerce" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900" role="menuitem">Tienda online, e-commerce</a>
            <a href="/apps/progressive-web-apps" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900" role="menuitem">Progressive Web Apps</a>
            <a href="/paginas-web/desarrollo-personalizado" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900" role="menuitem">Desarrollos y soluciones a necesidades especificas</a>
          </div>
        </li>
         <?php if (isset($component)) { $__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SingleMenuItem::class, ['rute' => 'marketing-digital/google-ads','name' => 'Marketing digital','icon' => 'M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z']); ?>
<?php $component->withName('single-menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af)): ?>
<?php $component = $__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af; ?>
<?php unset($__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

         <?php if (isset($component)) { $__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SingleMenuItem::class, ['rute' => 'portafolio/proyectos','name' => 'Portafolio de proyectos','icon' => 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10']); ?>
<?php $component->withName('single-menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af)): ?>
<?php $component = $__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af; ?>
<?php unset($__componentOriginalfe2ee4a08ab1d6ea430db30d8934bdbb76b4c1af); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
      </ul>
      <ul class="flex items-center">
        <li>
          <a href="/cotizar-en-linea" class="bg-gray-100 px-4 py-2 rounded-md shadow">
            Cotiza en línea
          </a>
        </li>
      </ul>
    </nav>
  </div>
</div><?php /**PATH C:\laragon\www\getweb-v2.1\resources\views/components/menu/nav-main.blade.php ENDPATH**/ ?>