


<?php $__env->startSection('seoTitle', 'Hosting más certificado SSL'); ?>
<?php $__env->startSection('seoDescription', 'Hosting comercial más certificado SSL y asistencia personalizada para tu pagina Web.'); ?>
<?php $__env->startSection('seoKeywords','hosting, colombia, bogota'); ?>
<?php $__env->startSection('seoRobots', 'index, follow'); ?>

<?php $__env->startSection('content'); ?>

 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.banner.page','data' => ['imgRute' => ''.e(asset('images/banners/banner-hosting.jpg')).'','text1' => 'Planes de Hosting','text2' => 'HOSTING COMERCIAL MÁS CERTIFICADO SSL','text3' => '¿Necesitas un hosting para tu sitio web? Ofrecemos planes de hosting que te permitirá una gran flexibilidad y alojamiento. Si no estás seguro siempre puedes llamar al equipo de asesores de Getweb y pregunta que tipo de hosting ideal para ti.']]); ?>
<?php $component->withName('banner.page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['imgRute' => ''.e(asset('images/banners/banner-hosting.jpg')).'','text1' => 'Planes de Hosting','text2' => 'HOSTING COMERCIAL MÁS CERTIFICADO SSL','text3' => '¿Necesitas un hosting para tu sitio web? Ofrecemos planes de hosting que te permitirá una gran flexibilidad y alojamiento. Si no estás seguro siempre puedes llamar al equipo de asesores de Getweb y pregunta que tipo de hosting ideal para ti.']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<div class="bg-c-morado py-2 px-8">
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.section-title','data' => ['text1' => 'Nuestros precios','style1' => 'text-white','text2' => 'Planes de hosting más certificado SSL','style2' => 'text-white','text3' => 'Planes y servicios de hosting anuales en servidores Linux','style3' => 'text-white']]); ?>
<?php $component->withName('modulo.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text1' => 'Nuestros precios','style1' => 'text-white','text2' => 'Planes de hosting más certificado SSL','style2' => 'text-white','text3' => 'Planes y servicios de hosting anuales en servidores Linux','style3' => 'text-white']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>


<div class="overflow-visible bg-gradient-to-b from-c-morado via-white to-white pb-4 px-8">
  <div class="flex justify-center flex-col sm:flex-row space-y-6 sm:space-y-0 space-x-0 sm:space-x-6">

     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.card-price-hosting','data' => ['type' => 'Basico','subtype' => 'Hosting','price' => '100.000','info' => 'Recursos básicos para los sitios que están empezando.','domain' => '1','db' => '2','banda' => '1','space' => '500MB','mail' => '1','ftp' => '1']]); ?>
<?php $component->withName('modulo.card-price-hosting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'Basico','subtype' => 'Hosting','price' => '100.000','info' => 'Recursos básicos para los sitios que están empezando.','domain' => '1','db' => '2','banda' => '1','space' => '500MB','mail' => '1','ftp' => '1']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.card-price-hosting','data' => ['type' => 'Emprendedor','subtype' => 'Hosting','price' => '150.000','info' => 'Más espacio, recursos y flexibilidad para tu sitio.','domain' => '1','db' => '5','banda' => '5','space' => '1GB','mail' => '2','ftp' => '2']]); ?>
<?php $component->withName('modulo.card-price-hosting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'Emprendedor','subtype' => 'Hosting','price' => '150.000','info' => 'Más espacio, recursos y flexibilidad para tu sitio.','domain' => '1','db' => '5','banda' => '5','space' => '1GB','mail' => '2','ftp' => '2']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.card-price-hosting','data' => ['type' => 'Empresario','subtype' => 'Hosting','price' => '300.000','info' => 'Más potencia para los sitios complejos y el tráfico pesado.','domain' => 'Ilimitados','db' => '5','banda' => '30','space' => '5GB','mail' => '5','ftp' => '5']]); ?>
<?php $component->withName('modulo.card-price-hosting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'Empresario','subtype' => 'Hosting','price' => '300.000','info' => 'Más potencia para los sitios complejos y el tráfico pesado.','domain' => 'Ilimitados','db' => '5','banda' => '30','space' => '5GB','mail' => '5','ftp' => '5']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.card-price-hosting','data' => ['type' => 'Corporativo','subtype' => 'Hosting','price' => '500.000','info' => 'Soporta múltiples sitios complejos con gran información.','domain' => 'Ilimitados','db' => '10','banda' => '60','space' => '10GB','mail' => '10','ftp' => 'Ilimitados']]); ?>
<?php $component->withName('modulo.card-price-hosting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'Corporativo','subtype' => 'Hosting','price' => '500.000','info' => 'Soporta múltiples sitios complejos con gran información.','domain' => 'Ilimitados','db' => '10','banda' => '60','space' => '10GB','mail' => '10','ftp' => 'Ilimitados']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    
  </div>
</div>


<div class="py-2 px-8">
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.section-title','data' => ['text1' => 'Nuestros proceso','style1' => 'text-black','text2' => '¿Cómo funciona el servicio?','style2' => 'text-c-rojo','text3' => 'El proceso se enfocan en 3 diferentes etapas de servicio','style3' => 'text-gray-500']]); ?>
<?php $component->withName('modulo.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text1' => 'Nuestros proceso','style1' => 'text-black','text2' => '¿Cómo funciona el servicio?','style2' => 'text-c-rojo','text3' => 'El proceso se enfocan en 3 diferentes etapas de servicio','style3' => 'text-gray-500']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>

<div class="py-4 px-8">
  <div class="flex sm:flex-row flex-col justify-center border border-gray-300 rounded sm:divide-x divide-y divide-gray-200">
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.step-price-hosting','data' => ['step' => '1','style' => 'bg-pink-400','text1' => 'Llámenos o escribanos','text2' => 'Hacemos una breve llamada telefónica con preguntas sobre tu proyecto o negocio y dominio.']]); ?>
<?php $component->withName('modulo.step-price-hosting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['step' => '1','style' => 'bg-pink-400','text1' => 'Llámenos o escribanos','text2' => 'Hacemos una breve llamada telefónica con preguntas sobre tu proyecto o negocio y dominio.']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.step-price-hosting','data' => ['step' => '2','style' => 'bg-pink-600','text1' => 'Contratas el servicio','text2' => 'Realizas el pago por el servicio y envias la información solicitada de tu dominio.']]); ?>
<?php $component->withName('modulo.step-price-hosting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['step' => '2','style' => 'bg-pink-600','text1' => 'Contratas el servicio','text2' => 'Realizas el pago por el servicio y envias la información solicitada de tu dominio.']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.step-price-hosting','data' => ['step' => '3','style' => 'bg-pink-700','text1' => 'Configuracion y entrega','text2' => 'Activamos y configuramos tu nuevo Hosting, certificado SSL y apuntamos tu Dominio en menos de 24 horas para que empieces a usarlo.']]); ?>
<?php $component->withName('modulo.step-price-hosting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['step' => '3','style' => 'bg-pink-700','text1' => 'Configuracion y entrega','text2' => 'Activamos y configuramos tu nuevo Hosting, certificado SSL y apuntamos tu Dominio en menos de 24 horas para que empieces a usarlo.']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
  </div>
</div>


 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.cta.main','data' => []]); ?>
<?php $component->withName('cta.main'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<div class="py-2 px-8">
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.section-title','data' => ['text1' => 'Nuestro servicio','style1' => 'text-black','text2' => '¿POR QUE PREFERIR LOS SERVICIOS DE GETWEB?','style2' => 'text-c-rojo','text3' => 'Somos profesionales con experiencia de más de 8 años en el mercado en el servicio de hosting','style3' => 'text-gray-500']]); ?>
<?php $component->withName('modulo.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text1' => 'Nuestro servicio','style1' => 'text-black','text2' => '¿POR QUE PREFERIR LOS SERVICIOS DE GETWEB?','style2' => 'text-c-rojo','text3' => 'Somos profesionales con experiencia de más de 8 años en el mercado en el servicio de hosting','style3' => 'text-gray-500']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
<div class="pb-4 px-8">
  <div class="flex justify-center flex-col sm:flex-row space-y-6 sm:space-y-0 space-x-0 sm:space-x-6">
    <div class="w-full sm:w-1/2 border border-gray-300 p-6 rounded">
      <h4 class="text-lg leading-6 font-medium text-gray-900">Garantía de cumplimiento y Máxima confiabilidad</h4>
      <p class="text-sm text-gray-700 border-l-2 border-gray-200 pl-3"><span class="block text-md font-bold my-3 text-c-rojo">Entendemos que no hay nada más frustrante que el tiempo de inactividad del servidor. Cuando su sitio web está inactivo, significa que sus visitantes no pueden leer su contenido y, lo más importante, no pueden comprar en su sitio. Es una pérdida total de oportunidades, así como una pérdida de tiempo y trabajo duro.</span> En Getweb seleccionamos a nuestros ingenieros y usamos solo el mejor hardware, redes, centros de datos, software y técnicas de la industria para garantizar que nuestros servidores funcionen con un rendimiento óptimo. 
        Al final del día, queremos que duerma tranquilo sabiendo que tomó la decisión correcta al elegir a Getweb Hosting para todas sus necesidades de alojamiento web. <br><br>Queremos que se sienta seguro de que su negocio está en nuestras manos de confianza. ¡Es por eso que su cuenta de alojamiento web también incluirá nuestro compromiso de tiempo de actividad del 99,9%.</p>
      </div>
      <div class="w-full sm:w-1/2 border border-gray-300 p-6 rounded">
        <h4 class="text-lg leading-6 font-medium text-gray-900">Tecnología avanzada, Seguridad y Planes escalables</h4>
        <p class="text-sm text-gray-700 border-l-2 border-gray-200 pl-3"><span class="block text-md font-bold my-3 text-c-rojo">Desde nuestro lanzamiento, hemos tenido un fuerte enfoque en cargar las mejores versiones del software de desarrollo más popular. ¡Nuestros servidores también admiten versiones anteriores! Algunos de los software de desarrollo disponibles en su cuenta incluyen: PHP 5.6, 7.1, 7.2, 7.3, 7.4 u 8.0 (elija su versión) MySQL 5.6 / MariaDB PostgreSQL 9.6 Python 3.4 PERL 5.10 Apache 2.4 Node.js 12 FTP / SFTP Acceso SSH gratuito SSL y SSL gratuito.
        </span> Ademas su cuenta incluye Protección HackScan gratuita para ayudar a bloquear los ataques antes de que puedan dañar su sitio. Las actualizaciones del kernel sin reinicio de KernelCare, la defensa de fuerza bruta, un firewall dual y una serie de otras características de seguridad ya están implementadas para ayudar a mantener su sitio seguro cuando elige Getweb Hosting. Nuestra protección reforzada de denegación de servicio distribuida ( DDoS ) incluso mejora la probabilidad de que su sitio permanezca en línea incluso durante los ataques de denegación de servicio distribuidos más sofisticados.<br><br>A medida que su sitio web crece, también puede hacerlo su plan de alojamiento. Nuestro equipo puede ayudarlo a mover sus sitios y su cuenta sin problemas a un plan de alojamiento de mayores recursos si supera su plan actual.</p>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\getweb-v2.1\resources\views/pages/hosting.blade.php ENDPATH**/ ?>