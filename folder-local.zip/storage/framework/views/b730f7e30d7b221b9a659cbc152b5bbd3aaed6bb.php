


<?php $__env->startSection('seoTitle', 'Portafolio de proyectos'); ?>
<?php $__env->startSection('seoDescription', 'Portafolio de proyectos de la empresa especializada en hosting, diseño y desarrollo de paginas web profesionales y marketing digital.'); ?>
<?php $__env->startSection('seoKeywords','portafolio, paginas web bogota, hosting, marketing digital'); ?>
<?php $__env->startSection('seoRobots', 'index, follow'); ?>

<?php $__env->startSection('content'); ?>


<div class="bg-gradient-to-r from-c-rojo to-c-morado py-2 px-8">
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.section-title','data' => ['text1' => 'Galeria de trabajos','style1' => 'text-white','text2' => 'Portafolio de proyectos','style2' => 'text-white','text3' => 'Visualiza algunos de nuestros productos','style3' => 'text-white']]); ?>
<?php $component->withName('modulo.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text1' => 'Galeria de trabajos','style1' => 'text-white','text2' => 'Portafolio de proyectos','style2' => 'text-white','text3' => 'Visualiza algunos de nuestros productos','style3' => 'text-white']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
<div class="bg-gray-100">
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('work-component')->html();
} elseif ($_instance->childHasBeenRendered('pfyow5l')) {
    $componentId = $_instance->getRenderedChildComponentId('pfyow5l');
    $componentTag = $_instance->getRenderedChildComponentTagName('pfyow5l');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pfyow5l');
} else {
    $response = \Livewire\Livewire::mount('work-component');
    $html = $response->html();
    $_instance->logRenderedChild('pfyow5l', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\getweb-v2.1\resources\views/portfolio/index.blade.php ENDPATH**/ ?>