


<?php $__env->startSection('seoTitle', 'Cotiza en línea'); ?>
<?php $__env->startSection('seoDescription', 'Cotiza los servicios de Getweb en linea, hosting, paginas web, pwa y pautas de google ads.'); ?>
<?php $__env->startSection('seoKeywords','cotizar, colombia, bogota'); ?>
<?php $__env->startSection('seoRobots', 'index, follow'); ?>

<?php $__env->startSection('content'); ?>


<div class="bg-gray-200 py-2 px-8">
   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modulo.section-title','data' => ['text1' => 'cotizador automático en linea','style1' => 'text-gray-700','text2' => 'Cotiza nuestros servicios','style2' => 'text-gray-900','text3' => 'Realiza tu cotización formal sobre nuestros productos de forma instantánea','style3' => 'text-gray-600']]); ?>
<?php $component->withName('modulo.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text1' => 'cotizador automático en linea','style1' => 'text-gray-700','text2' => 'Cotiza nuestros servicios','style2' => 'text-gray-900','text3' => 'Realiza tu cotización formal sobre nuestros productos de forma instantánea','style3' => 'text-gray-600']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('quote-component')->html();
} elseif ($_instance->childHasBeenRendered('Z2RvVVF')) {
    $componentId = $_instance->getRenderedChildComponentId('Z2RvVVF');
    $componentTag = $_instance->getRenderedChildComponentTagName('Z2RvVVF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Z2RvVVF');
} else {
    $response = \Livewire\Livewire::mount('quote-component');
    $html = $response->html();
    $_instance->logRenderedChild('Z2RvVVF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\getweb-v2.1\resources\views/pages/quote.blade.php ENDPATH**/ ?>