<div>


  single post


</div>
<?php /**PATH C:\laragon\www\getweb-v2.1\resources\views/livewire/w-single.blade.php ENDPATH**/ ?>