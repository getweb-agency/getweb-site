<li class="pb-4">
  <a href="/<?php echo e($rute); ?>" class="<?php echo e(request()->is( $rute ) ? 'bg-gray-200 rounded' : ''); ?>

    -m-2 p-2 flex items-start">
    <svg class="flex-shrink-0 h-5 w-5 text-pink-400 stroke-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo e($icon); ?>" />
    </svg>
    <div class="ml-1 text-sm text-gray-900">
      <?php echo e($name); ?> 
    </div>
  </a>
</li><?php /**PATH C:\laragon\www\getweb-v2.1\resources\views/components/single-menu-item-movil.blade.php ENDPATH**/ ?>